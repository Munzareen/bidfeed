<script src="{{ asset('public/assets/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('public/assets/js/jquery-3.5.1.min.js') }}"></script>
<script src="{{ asset('public/assets/js/swiper-bundle.min.js') }}"></script>
<script src="{{ asset('public/assets/js/fancybox.js') }}"></script>
<script src="{{ asset('public/assets/js/minimasonry.js') }}"></script>
<script src="{{ asset('public/assets/js/filepond-min.js') }}"></script>
<script src="{{ asset('public/assets/js/nouislider.min.js') }}"></script>
<script src="{{ asset('public/assets/js/custom.js') }}"></script>

<!-- Notification -->
<script src="{{ asset('public/assets/notification/js/jquery.growl.js') }}"></script>
<script src="{{ asset('public/assets/notification/js/notifIt.js') }}"></script>
<script src="{{ asset('public/assets/notification/js/rainbow.js') }}"></script>
<!-- <script src="{{ asset('public/assets/notification/js/sample.js') }}"></script> -->
@stack('scripts')