
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>

<section class="featured-sec bg-color">
	<div class="container">
		<div class="feature-top">
			<p class="title">Featured</p>
			<a href="#!" class="see-all">See All <span><img src="<?php echo e(asset('public/assets/images/purple-arrow-right.svg')); ?>" alt="icon" class="img-fluid"></span></a>
		</div>
	</div>	
	<div class="featured-slider-wrap">
		<div class="swiper featured-slider">
			<div class="swiper-wrapper">
				<?php if(!empty($featured) && count($featured) > 0): ?>
				<?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $featured): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="swiper-slide">
					<div class="feature-img">
						<a href="<?php echo e($featured->product_image); ?>" data-fancybox="gallery" data-caption="">
							<img src="<?php echo e($featured->product_image); ?>" alt="img" class="img-fluid">
						</a>	
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>

<section class="upcoming-sec bg-color">
	<div class="container">
		<div class="feature-top">
			<p class="title">Upcoming</p>
			<button class="filter-btn">
				<span><img src="<?php echo e(asset('public/assets/images/icon-filter.png')); ?>" alt="icon" class="img-fluid"></span>
				Filters
			</button>
		</div>
		<div class="upcoming-gallery-wrap">
			<div class="upcoming-gallery">
				<?php if(!empty($upcoming) && count($upcoming) > 0): ?>
				<?php $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $upcoming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e(url('product-details', base64_encode($upcoming->product_id))); ?>">
					<div class="gallery-card-wrap">
						<div class="gallery-card">
							<div class="gallery-img">
								<img src="<?php echo e($upcoming->product_image); ?>" alt="img" class="img-fluid">
								<a href="javascript:void(0);" class="like-btn like-this <?php if($upcoming->is_liked == 1): ?> active-like <?php endif; ?>" source="<?php echo e(base64_encode($upcoming->product_id)); ?>" type="product">
									<img src="<?php echo e(asset('public/assets/images/icon-heart.png')); ?>" alt="icon" class="img-fluid">
								</a>
							</div>
							<div class="gallery-info">
								<p class="name"><?php echo e($upcoming->product_description); ?></p>
								<div class="card-user-info">
									<div class="name-img">
										<div class="img">
											<?php if(!empty($upcoming->user_image)): ?>
											<img src="<?php echo e($upcoming->user_image); ?>" alt="icon" class="img-fluid">
											<?php else: ?>
											<img src="<?php echo e(asset('public/assets/images/gallery-user-img.png')); ?>" alt="icon" class="img-fluid">
											<?php endif; ?>
										</div>
										<div class="user-name"><p><?php echo e($upcoming->user_name); ?></p></div>
									</div>
									
								</div>
							</div>
						</div>
					</div>
				</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</div>
			<div class="gallery-col last-col">
				<button class="load-btn">Load more cards</button>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('public/assets/js/custom/home.js')); ?>"></script> 
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-projects\big-feed\resources\views/index.blade.php ENDPATH**/ ?>