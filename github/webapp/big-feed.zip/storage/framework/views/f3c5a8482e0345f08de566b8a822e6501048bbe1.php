<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> | E-commerce</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
	<link rel="icon" href="<?php echo e(asset('public/assets/images/header-logo.png')); ?>" />
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .active-like{
            background-color: red !important;
        }
    </style>
</head>
<body>
    <?php if(url()->current() != url('sign-in') && url()->current() != url('sign-up') && url()->current() != url('otp-verification') && url()->current() != url('/')): ?>
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?> 
    <input type="hidden" id="baseUrl" value="<?php echo e(url('/')); ?>" />
	<input type="hidden" id="apiBaseUrl" value="<?php echo e($data['apiBaseUrl']); ?>" />
    <?php if(Session::has('success')): ?> <input type="hidden" id="mSg" color="success" value="<?php echo e(Session::get('success')); ?>"> <?php endif; ?>
	<?php if(Session::has('error')): ?> <input type="hidden" id="mSg" color="error" value="<?php echo e(Session::get('error')); ?>"> <?php endif; ?>
    <?php if(url()->current() != url('sign-in') && url()->current() != url('sign-up') && url()->current() != url('otp-verification') && url()->current() != url('/')): ?>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make('layouts.footer-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\my-projects\big-feed\resources\views/layouts/master.blade.php ENDPATH**/ ?>