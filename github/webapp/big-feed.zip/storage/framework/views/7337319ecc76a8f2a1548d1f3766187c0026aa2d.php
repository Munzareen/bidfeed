<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/font-awesome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/swiper-bundle.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/fancybox.css')); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800&display=swap" rel="stylesheet">	

<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/nouislider.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/filepond-min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/responsive.css')); ?>" />

<!-- Notification -->
<link rel="stylesheet" href="<?php echo e(asset('public/assets/notification/css/jquery.growl.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/notification/css/notifIt.css')); ?>"><?php /**PATH C:\xampp\htdocs\my-projects\big-feed\resources\views/layouts/header.blade.php ENDPATH**/ ?>